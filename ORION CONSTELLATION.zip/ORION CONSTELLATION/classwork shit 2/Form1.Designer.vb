﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btnShow = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.lbl1 = New System.Windows.Forms.Label()
        Me.lbl2 = New System.Windows.Forms.Label()
        Me.lbl3 = New System.Windows.Forms.Label()
        Me.lbl4 = New System.Windows.Forms.Label()
        Me.lbl5 = New System.Windows.Forms.Label()
        Me.lbl6 = New System.Windows.Forms.Label()
        Me.lbl7 = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(94, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(397, 429)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'btnShow
        '
        Me.btnShow.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnShow.Location = New System.Drawing.Point(48, 447)
        Me.btnShow.Name = "btnShow"
        Me.btnShow.Size = New System.Drawing.Size(108, 110)
        Me.btnShow.TabIndex = 1
        Me.btnShow.Text = "SHOW STAR NAMES"
        Me.btnShow.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(237, 447)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(108, 110)
        Me.Button2.TabIndex = 2
        Me.Button2.Text = "HIDE STAR NAMES"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(416, 447)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(108, 110)
        Me.Button3.TabIndex = 3
        Me.Button3.Text = "EXIT"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'lbl1
        '
        Me.lbl1.AutoSize = True
        Me.lbl1.BackColor = System.Drawing.Color.SkyBlue
        Me.lbl1.Location = New System.Drawing.Point(186, 57)
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(60, 13)
        Me.lbl1.TabIndex = 4
        Me.lbl1.Text = "Betelgeuse" & Global.Microsoft.VisualBasic.ChrW(9)
        '
        'lbl2
        '
        Me.lbl2.AutoSize = True
        Me.lbl2.BackColor = System.Drawing.Color.SkyBlue
        Me.lbl2.Location = New System.Drawing.Point(382, 89)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(46, 13)
        Me.lbl2.TabIndex = 5
        Me.lbl2.Text = " Meissa "
        '
        'lbl3
        '
        Me.lbl3.AutoSize = True
        Me.lbl3.BackColor = System.Drawing.Color.SkyBlue
        Me.lbl3.Location = New System.Drawing.Point(171, 248)
        Me.lbl3.Name = "lbl3"
        Me.lbl3.Size = New System.Drawing.Size(39, 13)
        Me.lbl3.TabIndex = 6
        Me.lbl3.Text = "Alnitak" & Global.Microsoft.VisualBasic.ChrW(9)
        '
        'lbl4
        '
        Me.lbl4.AutoSize = True
        Me.lbl4.BackColor = System.Drawing.Color.SkyBlue
        Me.lbl4.Location = New System.Drawing.Point(246, 213)
        Me.lbl4.Name = "lbl4"
        Me.lbl4.Size = New System.Drawing.Size(40, 13)
        Me.lbl4.TabIndex = 7
        Me.lbl4.Text = "Alnilam" & Global.Microsoft.VisualBasic.ChrW(9)
        '
        'lbl5
        '
        Me.lbl5.AutoSize = True
        Me.lbl5.BackColor = System.Drawing.Color.SkyBlue
        Me.lbl5.Location = New System.Drawing.Point(336, 213)
        Me.lbl5.Name = "lbl5"
        Me.lbl5.Size = New System.Drawing.Size(45, 13)
        Me.lbl5.TabIndex = 8
        Me.lbl5.Text = "Mintaka" & Global.Microsoft.VisualBasic.ChrW(9)
        '
        'lbl6
        '
        Me.lbl6.AutoSize = True
        Me.lbl6.BackColor = System.Drawing.Color.SkyBlue
        Me.lbl6.Location = New System.Drawing.Point(129, 384)
        Me.lbl6.Name = "lbl6"
        Me.lbl6.Size = New System.Drawing.Size(34, 13)
        Me.lbl6.TabIndex = 9
        Me.lbl6.Text = "Saiph" & Global.Microsoft.VisualBasic.ChrW(9)
        '
        'lbl7
        '
        Me.lbl7.AutoSize = True
        Me.lbl7.BackColor = System.Drawing.Color.SkyBlue
        Me.lbl7.Location = New System.Drawing.Point(382, 361)
        Me.lbl7.Name = "lbl7"
        Me.lbl7.Size = New System.Drawing.Size(31, 13)
        Me.lbl7.TabIndex = 10
        Me.lbl7.Text = "Rigel" & Global.Microsoft.VisualBasic.ChrW(9)
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(588, 569)
        Me.Controls.Add(Me.lbl7)
        Me.Controls.Add(Me.lbl6)
        Me.Controls.Add(Me.lbl5)
        Me.Controls.Add(Me.lbl4)
        Me.Controls.Add(Me.lbl3)
        Me.Controls.Add(Me.lbl2)
        Me.Controls.Add(Me.lbl1)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.btnShow)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "Form1"
        Me.Text = "ORION CONSTELLATION"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btnShow As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents lbl1 As Label
    Friend WithEvents lbl2 As Label
    Friend WithEvents lbl3 As Label
    Friend WithEvents lbl4 As Label
    Friend WithEvents lbl5 As Label
    Friend WithEvents lbl6 As Label
    Friend WithEvents lbl7 As Label
End Class
